package com._2884omgpy.infinity_pattern_provider.init;

import appeng.api.AECapabilities;
import appeng.api.crafting.IPatternDetails;
import appeng.api.integrations.igtooltip.BaseClassRegistration;
import appeng.api.networking.GridServices;
import appeng.api.networking.IInWorldGridNodeHost;
import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import com._2884omgpy.infinity_pattern_provider.blockentity.InfinityPatternProviderBlockEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

@EventBusSubscriber(modid = InfinityPatternProvider.MOD_ID)
public class AddBlockEntityToAE2Network
{
    @SubscribeEvent
    public static void ModPatternProviderConnectToAE2Network(RegisterCapabilitiesEvent event)
    {
        event.registerBlockEntity(AECapabilities.IN_WORLD_GRID_NODE_HOST, ModBlockEntities._1SLOTS_PATTERN_PROVIDER.get(), (blockEntity, side) -> (IInWorldGridNodeHost) blockEntity);
        event.registerBlockEntity(AECapabilities.IN_WORLD_GRID_NODE_HOST, ModBlockEntities._32SLOTS_PATTERN_PROVIDER.get(), (blockEntity, side) -> (IInWorldGridNodeHost) blockEntity);
        event.registerBlockEntity(AECapabilities.IN_WORLD_GRID_NODE_HOST, ModBlockEntities._1024SLOTS_PATTERN_PROVIDER.get(), (blockEntity, side) -> (IInWorldGridNodeHost) blockEntity);
        event.registerBlockEntity(AECapabilities.IN_WORLD_GRID_NODE_HOST, ModBlockEntities.INFINITY_PATTERN_PROVIDER.get(), (blockEntity, side) -> (IInWorldGridNodeHost) blockEntity);
    }
}
