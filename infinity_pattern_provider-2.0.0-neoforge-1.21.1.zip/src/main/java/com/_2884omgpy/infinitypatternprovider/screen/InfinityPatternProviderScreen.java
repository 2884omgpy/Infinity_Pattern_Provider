package com._2884omgpy.infinitypatternprovider.screen;

import appeng.client.gui.implementations.PatternProviderScreen;
import appeng.client.gui.style.ScreenStyle;
import appeng.menu.slot.AppEngSlot;
import com._2884omgpy.infinitypatternprovider.component.DownArrowButtonWidget;
import com._2884omgpy.infinitypatternprovider.component.UpArrowButtonWidget;
import com._2884omgpy.infinitypatternprovider.menu.InfinityPatternProviderMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

import java.util.List;

public class InfinityPatternProviderScreen extends PatternProviderScreen<InfinityPatternProviderMenu>
{
    private static final int PAGE_TEXT_X = 116;
    private static final int PAGE_TEXT_Y = 28;

    private static final int SLOTS_PER_PAGE = 32;
    private static final int TOTAL_PAGE = 1024;
    private int page = 0;
    private List<AppEngSlot> patternSlots;

    public InfinityPatternProviderScreen(InfinityPatternProviderMenu menu, Inventory playerInventory, Component title, ScreenStyle style)
    {
        super(menu, playerInventory, title, style);
        this.patternSlots = menu.getPatternSlots();

        for(int i = SLOTS_PER_PAGE ; i < 32723 ; i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            slot.setActive(false);
        }
    }

    @Override
    protected void init()
    {
        super.init();

        addButton();
        updateAllSlotPositions();
    }

    private void addButton()
    {
        UpArrowButtonWidget upArrowButton = new UpArrowButtonWidget(this.leftPos + 154, this.topPos + 41, button -> prevPage());
        DownArrowButtonWidget downArrowButton = new DownArrowButtonWidget(this.leftPos + 154, this.topPos + 91, button -> nextPage());

        addRenderableWidget(upArrowButton);
        addRenderableWidget(downArrowButton);
    }

    //更新所有槽位的位置
    private void updateAllSlotPositions()
    {
        if (patternSlots == null || patternSlots.isEmpty())
        {
            return;
        }

        for (int i = 0; i < patternSlots.size(); i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            setSlotPosition(slot, i);
        }
    }

    //设置槽位位置
    private void setSlotPosition(AppEngSlot slot, int slotIndex)
    {
        //x和y变量已经在访问变换器中强制去除了final修饰符，可以正常赋值
        slot.x = 8 + (slotIndex % 32) % 8 * 18;
        slot.y = 42 + (slotIndex % 32) / 8 * 18;

        //更新槽位状态
        slot.setChanged();
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY)
    {
        if (mouseX >= leftPos && mouseX < leftPos + width && mouseY >= topPos && mouseY < topPos + height)
        {
            if (scrollY > 0)
            {
                prevPage();
            }
            else
                if (scrollY < 0)
                {
                    nextPage();
                }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
    }

    //上一页
    public void prevPage()
    {
        PageSlotsUnVisible(page);
        if (page > 0)
        {
            page--;
        }
            else
            {
                page = TOTAL_PAGE - 1;
            }
        PageSlotsVisible(page);
    }

    //下一页
    public void nextPage()
    {
        PageSlotsUnVisible(page);
        if (page < TOTAL_PAGE - 1)
        {
            page++;
        }
            else
            {
                page = 0;
            }
        PageSlotsVisible(page);
    }

    private void PageSlotsVisible(int page)
    {
        for(int i = SLOTS_PER_PAGE * page ; i < SLOTS_PER_PAGE * page + SLOTS_PER_PAGE ; i++)
        {
            if(i < patternSlots.size())
            {
                AppEngSlot slot = patternSlots.get(i);
                slot.setActive(true);
            }
        }
    }

    private void PageSlotsUnVisible(int page)
    {
        for(int i = SLOTS_PER_PAGE * page ; i < SLOTS_PER_PAGE * page + SLOTS_PER_PAGE ; i++)
        {
            if (i < patternSlots.size())
            {
                AppEngSlot slot = patternSlots.get(i);
                slot.setActive(false);
            }
        }
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks)
    {
        super.render(guiGraphics, mouseX, mouseY, partialTicks);

        //显示页码
        guiGraphics.drawString(this.font, String.format("%04d", (page + 1)) + "/" + String.format("%04d", TOTAL_PAGE), leftPos + PAGE_TEXT_X, topPos + PAGE_TEXT_Y, 0x404040, false);
    }
}