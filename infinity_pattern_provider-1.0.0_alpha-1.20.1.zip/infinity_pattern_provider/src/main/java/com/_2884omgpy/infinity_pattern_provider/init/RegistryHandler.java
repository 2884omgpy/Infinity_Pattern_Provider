package com._2884omgpy.infinity_pattern_provider.init;

import appeng.api.parts.PartModels;
import appeng.core.AppEng;
import com._2884omgpy.infinity_pattern_provider.menu.InfinityPatternProviderMenu;
import com._2884omgpy.infinity_pattern_provider.menu._1024SlotsPatternProviderMenu;
import com._2884omgpy.infinity_pattern_provider.menu._1SlotsPatternProviderMenu;
import com._2884omgpy.infinity_pattern_provider.menu._32SlotsPatternProviderMenu;
import com._2884omgpy.infinity_pattern_provider.part.InfinityPatternProviderPart;
import com._2884omgpy.infinity_pattern_provider.part._1024SlotsPatternProviderPart;
import com._2884omgpy.infinity_pattern_provider.part._1SlotsPatternProviderPart;
import com._2884omgpy.infinity_pattern_provider.part._32SlotsPatternProviderPart;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegisterEvent;

public class RegistryHandler
{
    public static void init()
    {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.register(RegistryHandler.class);
    }

    //注册菜单
    @SubscribeEvent
    public static void MenuRegister(RegisterEvent event)
    {
        if (event.getRegistryKey().equals(ForgeRegistries.MENU_TYPES.getRegistryKey()))
        {
            //初始化菜单类型
            _1SlotsPatternProviderMenu.init();
            _32SlotsPatternProviderMenu.init();
            _1024SlotsPatternProviderMenu.init();
            InfinityPatternProviderMenu.init();

            //注册菜单
            event.register(ForgeRegistries.MENU_TYPES.getRegistryKey(), helper -> helper.register(AppEng.makeId("_1slots_pattern_provider"), _1SlotsPatternProviderMenu.TYPE));
            event.register(ForgeRegistries.MENU_TYPES.getRegistryKey(), helper -> helper.register(AppEng.makeId("_32slots_pattern_provider"), _32SlotsPatternProviderMenu.TYPE));
            event.register(ForgeRegistries.MENU_TYPES.getRegistryKey(), helper -> helper.register(AppEng.makeId("_1024slots_pattern_provider"), _1024SlotsPatternProviderMenu.TYPE));
            event.register(ForgeRegistries.MENU_TYPES.getRegistryKey(), helper -> helper.register(AppEng.makeId("infinity_pattern_provider"), InfinityPatternProviderMenu.TYPE));
        }
    }

    private static boolean registered = false;

    //注册AE2线缆组件部分
    @SubscribeEvent
    public static void PartModelRegister(RegisterEvent event)
    {
        if (registered)
        {
            return;
        }

        PartModels.registerModels(_1SlotsPatternProviderPart._1SLOTS_PATTERN_PROVIDER_BASE, _1SlotsPatternProviderPart.AE2_INTERFACE_OFF, _1SlotsPatternProviderPart.AE2_INTERFACE_ON, _1SlotsPatternProviderPart.AE2_INTERFACE_HAS_CHANNEL);
        PartModels.registerModels(_32SlotsPatternProviderPart._32SLOTS_PATTERN_PROVIDER_BASE, _32SlotsPatternProviderPart.AE2_INTERFACE_OFF, _32SlotsPatternProviderPart.AE2_INTERFACE_ON, _32SlotsPatternProviderPart.AE2_INTERFACE_HAS_CHANNEL);
        PartModels.registerModels(_1024SlotsPatternProviderPart._1024SLOTS_PATTERN_PROVIDER_BASE, _1024SlotsPatternProviderPart.AE2_INTERFACE_OFF, _1024SlotsPatternProviderPart.AE2_INTERFACE_ON, _1024SlotsPatternProviderPart.AE2_INTERFACE_HAS_CHANNEL);
        PartModels.registerModels(InfinityPatternProviderPart.INFINITY_PATTERN_PROVIDER_BASE, InfinityPatternProviderPart.AE2_INTERFACE_OFF, InfinityPatternProviderPart.AE2_INTERFACE_ON, InfinityPatternProviderPart.AE2_INTERFACE_HAS_CHANNEL);

        registered = true;
    }


}
