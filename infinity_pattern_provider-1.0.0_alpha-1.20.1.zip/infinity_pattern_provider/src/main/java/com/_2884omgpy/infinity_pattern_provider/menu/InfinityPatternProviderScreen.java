package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.client.gui.implementations.PatternProviderScreen;
import appeng.client.gui.style.ScreenStyle;
import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import com._2884omgpy.infinity_pattern_provider.network.PageChangePacket;
import com._2884omgpy.infinity_pattern_provider.network.ModNetworkHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;

public class InfinityPatternProviderScreen extends PatternProviderScreen<InfinityPatternProviderMenu>
{
    private static final ResourceLocation NEXT_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/next_button_hover.png");
    private static final ResourceLocation NEXT_BUTTON_NORMAL = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/next_button_normal.png");
    private static final ResourceLocation PREV_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/prev_button_hover.png");
    private static final ResourceLocation PREV_BUTTON_NORMAL = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/prev_button_normal.png");

    // 按钮位置定义
    private static final int PREV_BUTTON_AREA_START_X = 154;
    private static final int PREV_BUTTON_AREA_START_Y = 41;
    private static final int PREV_BUTTON_AREA_FINAL_X = 168;
    private static final int PREV_BUTTON_AREA_FINAL_Y = 62;

    private static final int NEXT_BUTTON_AREA_START_X = 154;
    private static final int NEXT_BUTTON_AREA_START_Y = 91;
    private static final int NEXT_BUTTON_AREA_FINAL_X = 168;
    private static final int NEXT_BUTTON_AREA_FINAL_Y = 112;

    private static final int WHEEL_AREA_START_X = 7;
    private static final int WHEEL_AREA_START_Y = 41;
    private static final int WHEEL_AREA_FINAL_X = 168;
    private static final int WHEEL_AREA_FINAL_Y = 112;

    private static final int PAGE_TEXT_X = 150;
    private static final int PAGE_TEXT_Y = 73;

    private boolean prevButtonHovered = false;
    private boolean nextButtonHovered = false;

    private static final int BUTTON_HEIGHT = 22;
    private static final int BUTTON_WIDTH = 15;

    private static final int TOTAL_PAGE = 1024;
    private static int currentPage = 0;

    public InfinityPatternProviderScreen(InfinityPatternProviderMenu menu, Inventory playerInventory, Component title, ScreenStyle style)
    {
        super(menu, playerInventory, title, style);
    }

    @Override
    protected void init()
    {
        super.init();
        currentPage = 0;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        int relX = (int) (mouseX - leftPos);
        int relY = (int) (mouseY - topPos);

        if (isInPrevButtonArea(relX, relY) && button == 0)
        {
            prevPage();
            playButtonClickSound();
            return true;
        }
        else
            if (isInNextButtonArea(relX, relY) && button == 0)
            {
                nextPage();
                playButtonClickSound();
                return true;
            }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta)
    {
        int relX = (int) (mouseX - leftPos);
        int relY = (int) (mouseY - topPos);

        if (isInWheelArea(relX, relY))
        {
            if (delta > 0)
            {
                prevPage();
            }
            else
                if (delta < 0)
                {
                    nextPage();
                }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    //上一页
    public void prevPage()
    {
        if (currentPage > 0)
        {
            currentPage--;
        }
            else
            {
                currentPage = TOTAL_PAGE - 1;
            }
        sendPageChangeRequest(currentPage);
    }

    //下一页
    public void nextPage()
    {
        if (currentPage < TOTAL_PAGE - 1)
        {
            currentPage++;
        }
            else
            {
                currentPage = 0;
            }
        sendPageChangeRequest(currentPage);
    }

    private void sendPageChangeRequest(int page)
    {
        ModNetworkHandler.CHANNEL.sendToServer(new PageChangePacket(page));
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks)
    {
        super.render(guiGraphics, mouseX, mouseY, partialTicks);

        //转换为相对于GUI的坐标
        int relX = mouseX - leftPos;
        int relY = mouseY - topPos;

        //更新按钮悬停状态
        prevButtonHovered = isInPrevButtonArea(relX, relY);
        nextButtonHovered = isInNextButtonArea(relX, relY);

        //显示页码（从菜单获取当前页码）
        guiGraphics.drawString(this.font, String.format("%04d", (currentPage + 1)), leftPos + PAGE_TEXT_X, topPos + PAGE_TEXT_Y, 0x404040, false);

        //渲染工具提示（”上一页“和”下一页“）
        renderTooltips(guiGraphics, mouseX, mouseY);
    }

    //渲染工具提示（”上一页“和”下一页“）
    private void renderTooltips(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if (prevButtonHovered)
        {
            guiGraphics.renderTooltip(this.font, Component.translatable("gui.infinitypatternprovider.prev_page"), mouseX, mouseY);
            guiGraphics.blit(PREV_BUTTON_HOVER, this.leftPos + 154, this.topPos + 41, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
        }
        else
            if (nextButtonHovered)
            {
                guiGraphics.renderTooltip(this.font, Component.translatable("gui.infinitypatternprovider.next_page"), mouseX, mouseY);
                guiGraphics.blit(NEXT_BUTTON_HOVER, this.leftPos + 154, this.topPos + 91, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
            }
                else
                {
                    guiGraphics.blit(PREV_BUTTON_NORMAL, this.leftPos + 154, this.topPos + 41, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
                    guiGraphics.blit(NEXT_BUTTON_NORMAL, this.leftPos + 154, this.topPos + 91, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
                }
    }

    //检查是否在上一页按钮区域内
    private boolean isInPrevButtonArea(int relX, int relY)
    {
        return relX >= PREV_BUTTON_AREA_START_X && relX <= PREV_BUTTON_AREA_FINAL_X && relY >= PREV_BUTTON_AREA_START_Y && relY <= PREV_BUTTON_AREA_FINAL_Y;
    }

    //检查是否在下一页按钮区域内
    private boolean isInNextButtonArea(int relX, int relY)
    {
        return relX >= NEXT_BUTTON_AREA_START_X && relX <= NEXT_BUTTON_AREA_FINAL_X && relY >= NEXT_BUTTON_AREA_START_Y && relY <= NEXT_BUTTON_AREA_FINAL_Y;
    }

    //检查是否在滚轮区域内
    private boolean isInWheelArea(int relX, int relY)
    {
        return relX >= WHEEL_AREA_START_X && relX <= WHEEL_AREA_FINAL_X && relY >= WHEEL_AREA_START_Y && relY <= WHEEL_AREA_FINAL_Y;
    }

    //播放按钮点击声音
    private void playButtonClickSound()
    {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }
}