package com._2884omgpy.infinity_pattern_provider.network;

import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModNetworkHandler
{
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(ResourceLocation.fromNamespaceAndPath("infinity_pattern_provider", "main"), () -> PROTOCOL_VERSION, PROTOCOL_VERSION::equals, PROTOCOL_VERSION::equals);

    private static int packetId = 0;

    public static void register()
    {
        // 注册页面切换包
        CHANNEL.registerMessage(packetId++, PageChangePacket.class, PageChangePacket::encode, PageChangePacket::decode, PageChangePacket::handle);
    }
}