package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.helpers.patternprovider.PatternProviderLogicHost;
import appeng.menu.SlotSemantics;
import appeng.menu.implementations.MenuTypeBuilder;
import appeng.menu.implementations.PatternProviderMenu;
import appeng.menu.slot.AppEngSlot;
import appeng.menu.slot.RestrictedInputSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.MenuType;

import java.util.List;
import java.util.Map;

public class _32SlotsPatternProviderMenu extends PatternProviderMenu
{
    public static MenuType<_32SlotsPatternProviderMenu> TYPE;

    private static final int PATTERN_SLOT_ROWS = 4;     //4行
    private static final int PATTERN_SLOT_COLS = 8;     //8列
    private static final int PATTERN_SLOT_COUNT = 32;   //32格

    private static final int PATTERN_START_X = 8;       //起始X=8
    private static final int PATTERN_START_Y = 42;      //起始Y=42

    public static void init()
    {
        if (TYPE == null)
        {
            TYPE = MenuTypeBuilder.create(_32SlotsPatternProviderMenu::new, PatternProviderLogicHost.class).build("_32slots_pattern_provider");
        }
    }

    public _32SlotsPatternProviderMenu(int id, Inventory playerInventory, PatternProviderLogicHost host)
    {
        super(TYPE, id, playerInventory, host);
        resetPatternSlots();
    }

    //重新设置槽位
    private void resetPatternSlots()
    {
        //获取样板库存
        var patternInv = logic.getPatternInv();

        //移除原有的ENCODED_PATTERN槽位
        removeExistingPatternSlots();

        //添加新的4×8布局槽位
        for (int i = 0; i < 32; i++)
        {
            if (i >= patternInv.size())
            {
                break;
            }

            //行数/列数
            int row = i / PATTERN_SLOT_COLS;
            int col = i % PATTERN_SLOT_COLS;

            //xy坐标
            int xPos = PATTERN_START_X + col * 18;
            int yPos = PATTERN_START_Y + row * 18;

            //创建槽位
            AppEngSlot slot = SlotPositionHelper.createFixedPositionRestrictedSlot(RestrictedInputSlot.PlacableItemType.ENCODED_PATTERN, patternInv, i, xPos, yPos);

            //添加到菜单
            this.addSlot(slot, SlotSemantics.ENCODED_PATTERN);
        }
    }

    //清除自动添加的样板槽位
    private void removeExistingPatternSlots()
    {
        //获取所有ENCODED_PATTERN语义的槽位
        var slots = this.getSlots(SlotSemantics.ENCODED_PATTERN);

        //移除槽位
        for (var slot : slots)
        {
            this.slots.remove(slot);
        }

        //使用反射清除SlotSemantics映射
        try
        {
            var field = this.getSlots(SlotSemantics.ENCODED_PATTERN).getClass().getDeclaredField("slotsBySemantic");
            field.setAccessible(true);
            var map = (Map<SlotSemantics, List<AppEngSlot>>) field.get(this.getSlots(SlotSemantics.ENCODED_PATTERN));
            map.remove(SlotSemantics.ENCODED_PATTERN);
        }
            catch (Exception e)
            {
                System.err.println("无法移除槽位！！！");
            }
    }
}