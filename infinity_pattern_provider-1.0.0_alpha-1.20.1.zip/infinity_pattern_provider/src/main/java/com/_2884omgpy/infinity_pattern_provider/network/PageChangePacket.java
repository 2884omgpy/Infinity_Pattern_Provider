package com._2884omgpy.infinity_pattern_provider.network;

import com._2884omgpy.infinity_pattern_provider.menu.InfinityPatternProviderMenu;
import com._2884omgpy.infinity_pattern_provider.menu._1024SlotsPatternProviderMenu;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class PageChangePacket
{
    private final int newPage;

    public PageChangePacket(int newPage)
    {
        this.newPage = newPage;
    }

    public int getNewPage()
    {
        return newPage;
    }

    public static void encode(PageChangePacket packet, FriendlyByteBuf buffer)
    {
        buffer.writeInt(packet.newPage);
    }

    public static PageChangePacket decode(FriendlyByteBuf buffer)
    {
        return new PageChangePacket(buffer.readInt());
    }

    public static void handle(PageChangePacket packet, Supplier<NetworkEvent.Context> context)
    {
        NetworkEvent.Context ctx = context.get();
        ctx.enqueueWork(() ->
        {
            ServerPlayer player = ctx.getSender();
            if (player != null && player.containerMenu instanceof _1024SlotsPatternProviderMenu)
            {
                _1024SlotsPatternProviderMenu menu = (_1024SlotsPatternProviderMenu) player.containerMenu;
                menu.showPage(packet.getNewPage());
            }
            else
                if (player != null && player.containerMenu instanceof InfinityPatternProviderMenu)
                {
                    InfinityPatternProviderMenu menu = (InfinityPatternProviderMenu) player.containerMenu;
                    menu.showPage(packet.getNewPage());
                }
        });
        ctx.setPacketHandled(true);
    }
}