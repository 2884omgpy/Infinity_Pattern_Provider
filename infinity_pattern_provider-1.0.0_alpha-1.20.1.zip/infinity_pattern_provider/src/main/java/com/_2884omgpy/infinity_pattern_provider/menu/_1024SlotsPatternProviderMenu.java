package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.helpers.patternprovider.PatternProviderLogicHost;
import appeng.menu.AEBaseMenu;
import appeng.menu.SlotSemantics;
import appeng.menu.implementations.MenuTypeBuilder;
import appeng.menu.implementations.PatternProviderMenu;
import appeng.menu.slot.AppEngSlot;
import appeng.menu.slot.RestrictedInputSlot;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.MenuType;

import java.util.List;
import java.util.Map;

public class _1024SlotsPatternProviderMenu extends PatternProviderMenu
{
    public static MenuType<_1024SlotsPatternProviderMenu> TYPE;

    private static final int PATTERN_SLOT_ROWS = 4;     //4行
    private static final int PATTERN_SLOT_COLS = 8;     //8列
    private static final int PATTERN_SLOT_COUNT = 32;   //32格
    private static final int PATTERN_START_X = 8;       //起始X=8
    private static final int PATTERN_START_Y = 42;      //起始Y=42
    private static final int TOTAL_SLOTS = 1024;        //总槽位数

    public static void init()
    {
        TYPE = MenuTypeBuilder.create(_1024SlotsPatternProviderMenu::new, PatternProviderLogicHost.class).build("_1024slots_pattern_provider");
    }

    public _1024SlotsPatternProviderMenu(int id, Inventory playerInventory, PatternProviderLogicHost host)
    {
        super(TYPE, id, playerInventory, host);

        //移除原有的ENCODED_PATTERN槽位
        removeAllPatternSlots();

        // 初始显示第0页
        showPage(0);
    }

    public void showPage(int page)
    {
        //完全清除所有样板槽位
        removeAllPatternSlots();

        //添加当前页的槽位
        addPageSlots(page);
    }

    //清除所有ENCODED_PATTERN语义的槽位
    private void removeAllPatternSlots()
    {
        //获取所有ENCODED_PATTERN语义的槽位
        var patternSlots = this.getSlots(SlotSemantics.ENCODED_PATTERN);

        //移除槽位
        for (var slot : patternSlots)
        {
            this.slots.remove(slot);
        }

        //使用反射清除SlotSemantics映射
        try
        {
            var field = AEBaseMenu.class.getDeclaredField("slotsBySemantic");
            field.setAccessible(true);
            var map = (Map<SlotSemantics, List<AppEngSlot>>) field.get(this);
            map.remove(SlotSemantics.ENCODED_PATTERN);
        }
            catch (Exception e)
            {

            }
    }

    //重新设置槽位
    public void addPageSlots(int page)
    {
        int startIndex = page * 32;
        var patternInv = logic.getPatternInv();

        //添加新的4×8布局槽位
        for (int i = 0; i < 32; i++)

        {
            int slotIndex = startIndex + i;
            if (slotIndex >= TOTAL_SLOTS)
            {
                System.err.println("创建了超过总槽位数的slot！！！");
                break;
            }

            //行数/列数
            int row = i / PATTERN_SLOT_COLS;
            int col = i % PATTERN_SLOT_COLS;

            //xy坐标
            int xPos = PATTERN_START_X + col * 18;
            int yPos = PATTERN_START_Y + row * 18;

            //创建槽位
            AppEngSlot slot = SlotPositionHelper.createFixedPositionRestrictedSlot(RestrictedInputSlot.PlacableItemType.ENCODED_PATTERN, patternInv, slotIndex, xPos, yPos);

            //添加到菜单
            this.addSlot(slot, SlotSemantics.ENCODED_PATTERN);
        }
    }
}