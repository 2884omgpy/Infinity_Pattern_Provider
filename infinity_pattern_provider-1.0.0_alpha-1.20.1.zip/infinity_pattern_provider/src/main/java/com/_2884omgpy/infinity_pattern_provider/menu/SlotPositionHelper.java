package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.api.inventories.InternalInventory;
import appeng.menu.slot.AppEngSlot;
import appeng.menu.slot.RestrictedInputSlot;
import net.minecraft.world.inventory.Slot;

import java.lang.reflect.Field;

//槽位位置工具类，使用反射直接设置槽位位置
public class SlotPositionHelper
{
    private static Field slotXField = null;
    private static Field slotYField = null;

    static
    {
        try
        {
            // 获取Slot类的x和y字段
            slotXField = Slot.class.getDeclaredField("x");
            slotYField = Slot.class.getDeclaredField("y");

            // 设置字段可访问
            slotXField.setAccessible(true);
            slotYField.setAccessible(true);
        }
            catch (NoSuchFieldException e)
            {
                e.printStackTrace();
            }
    }

    //直接设置槽位的XY坐标
    public static void setSlotPosition(AppEngSlot slot, int x, int y)
    {
        if (slotXField != null && slotYField != null)
        {
            try
            {
                slotXField.set(slot, x);
                slotYField.set(slot, y);
            }
                catch (IllegalAccessException e)
                {
                    e.printStackTrace();
                }
        }
    }

    //创建固定位置的RestrictedInputSlot
    public static AppEngSlot createFixedPositionRestrictedSlot(RestrictedInputSlot.PlacableItemType type, InternalInventory inventory, int slotIndex, int x, int y)
    {
        AppEngSlot slot = new RestrictedInputSlot(type, inventory, slotIndex); //创建槽位
        setSlotPosition(slot, x, y);    //设置位置
        return slot;
    }
}