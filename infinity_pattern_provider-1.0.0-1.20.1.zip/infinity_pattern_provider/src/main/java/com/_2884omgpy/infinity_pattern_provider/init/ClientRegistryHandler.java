package com._2884omgpy.infinity_pattern_provider.init;

import appeng.init.client.InitScreens;
import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import com._2884omgpy.infinity_pattern_provider.menu.*;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = InfinityPatternProvider.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientRegistryHandler
{
    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event)
    {
        event.enqueueWork(() ->
        {
            if (_1SlotsPatternProviderMenu.TYPE != null)
            {
                try
                {
                    InitScreens.register(_1SlotsPatternProviderMenu.TYPE, _1SlotsPatternProviderScreen::new, "/screens/_1slots_pattern_provider.json");
                }
                catch (Exception e)
                {

                }
            }

            if (_32SlotsPatternProviderMenu.TYPE != null)
            {
                try
                {
                    InitScreens.register(_32SlotsPatternProviderMenu.TYPE, _32SlotsPatternProviderScreen::new, "/screens/_32slots_pattern_provider.json");
                }
                catch (Exception e)
                {

                }
            }

            if (_1024SlotsPatternProviderMenu.TYPE != null)
            {
                try
                {
                    InitScreens.register(_1024SlotsPatternProviderMenu.TYPE,_1024SlotsPatternProviderScreen::new, "/screens/_1024slots_pattern_provider.json");
                }
                catch (Exception e)
                {

                }
            }

            if (InfinityPatternProviderMenu.TYPE != null)
            {
                try
                {
                    InitScreens.register(InfinityPatternProviderMenu.TYPE, InfinityPatternProviderScreen::new, "/screens/infinity_pattern_provider.json");
                }
                    catch (Exception e)
                    {

                    }
            }
        });
    }
}