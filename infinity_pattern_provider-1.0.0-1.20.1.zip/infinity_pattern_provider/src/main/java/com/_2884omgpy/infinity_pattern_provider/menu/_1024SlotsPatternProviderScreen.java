package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.client.gui.implementations.PatternProviderScreen;
import appeng.client.gui.style.ScreenStyle;
import appeng.menu.slot.AppEngSlot;
import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;

import java.util.List;

public class _1024SlotsPatternProviderScreen extends PatternProviderScreen<_1024SlotsPatternProviderMenu>
{
    private static final ResourceLocation NEXT_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/next_button_hover.png");
    private static final ResourceLocation NEXT_BUTTON_NORMAL = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/next_button_normal.png");
    private static final ResourceLocation PREV_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/prev_button_hover.png");
    private static final ResourceLocation PREV_BUTTON_NORMAL = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/prev_button_normal.png");

    private static final int START_X = 8;
    private static final int START_Y = 42;

    private static final int BUTTON_HEIGHT = 22;
    private static final int BUTTON_WIDTH = 15;

    private static final int PREV_BUTTON_AREA_START_X = 154;
    private static final int PREV_BUTTON_AREA_START_Y = 41;
    private static final int PREV_BUTTON_AREA_FINAL_X = PREV_BUTTON_AREA_START_X + BUTTON_WIDTH;
    private static final int PREV_BUTTON_AREA_FINAL_Y = PREV_BUTTON_AREA_START_Y + BUTTON_HEIGHT;

    private static final int NEXT_BUTTON_AREA_START_X = 154;
    private static final int NEXT_BUTTON_AREA_START_Y = 91;
    private static final int NEXT_BUTTON_AREA_FINAL_X = NEXT_BUTTON_AREA_START_X + BUTTON_WIDTH;
    private static final int NEXT_BUTTON_AREA_FINAL_Y = NEXT_BUTTON_AREA_START_Y + BUTTON_HEIGHT;

    private static final int WHEEL_AREA_START_X = 7;
    private static final int WHEEL_AREA_START_Y = 41;
    private static final int WHEEL_AREA_FINAL_X = 168;
    private static final int WHEEL_AREA_FINAL_Y = 112;

    private static final int PAGE_TEXT_X = 140;
    private static final int PAGE_TEXT_Y = 28;

    private boolean prevButtonHovered = false;
    private boolean nextButtonHovered = false;

    private static final int SLOTS_PER_PAGE = 32;
    private static final int TOTAL_PAGE = 32;
    private int nowPage = 0;
    private int lastPage = 1;
    private List<AppEngSlot> patternSlots;

    public _1024SlotsPatternProviderScreen(_1024SlotsPatternProviderMenu menu, Inventory playerInventory, Component title, ScreenStyle style)
    {
        super(menu, playerInventory, title, style);
        this.patternSlots = menu.getPatternSlots();

        for(int i = SLOTS_PER_PAGE ; i < SLOTS_PER_PAGE * TOTAL_PAGE ; i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            slot.setActive(false);
        }
    }

    @Override
    protected void init()
    {
        super.init();
        updateAllSlotPositions();
    }

    //更新所有槽位的位置
    private void updateAllSlotPositions()
    {
        if (patternSlots == null || patternSlots.isEmpty())
        {
            return;
        }

        for (int i = 0; i < patternSlots.size(); i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            setSlotPosition(slot, i);
        }
    }

    //设置槽位位置
    @SuppressWarnings("java:S3011") //抑制java警告
    private void setSlotPosition(AppEngSlot slot, int slotIndex)
    {
        int row = (slotIndex % 32) / 8;
        int col = (slotIndex % 32) % 8;

        int x = START_X + col * 18;
        int y = START_Y + row * 18;

        //x和y变量已经在访问变换器中强制去除了final修饰符，实际上可以正常使用
        slot.x = x;
        slot.y = y;

        //强制更新槽位状态
        slot.setChanged();
    }

    //更新槽位可见性
    private void updateSlotVisibility()
    {
        if (patternSlots == null || patternSlots.isEmpty())
        {
            return;
        }

        PageSlotsUnVisible(lastPage);
        PageSlotsVisible(nowPage);
    }

    private void PageSlotsVisible(int page)
    {
        for(int i = SLOTS_PER_PAGE * page ; i < SLOTS_PER_PAGE * page + SLOTS_PER_PAGE ; i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            slot.setActive(true);
        }
    }

    private void PageSlotsUnVisible(int page)
    {
        for(int i = SLOTS_PER_PAGE * page ; i < SLOTS_PER_PAGE * page + SLOTS_PER_PAGE ; i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            slot.setActive(false);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button)
    {
        int relX = (int) (mouseX - leftPos);
        int relY = (int) (mouseY - topPos);

        if (isInPrevButtonArea(relX, relY) && button == 0)
        {
            prevPage();
            playButtonClickSound();
            return true;
        }
        else
            if (isInNextButtonArea(relX, relY) && button == 0)
            {
                nextPage();
                playButtonClickSound();
                return true;
            }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta)
    {
        int relX = (int) (mouseX - leftPos);
        int relY = (int) (mouseY - topPos);

        if (isInWheelArea(relX, relY))
        {
            if (delta > 0)
            {
                prevPage();
            }
            else
                if (delta < 0)
                {
                    nextPage();
                }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    //上一页
    public void prevPage()
    {
        lastPage = nowPage;
        if (nowPage > 0)
        {
            nowPage--;
        }
            else
            {
                nowPage = TOTAL_PAGE - 1;
            }
        updateSlotVisibility();
    }

    //下一页
    public void nextPage()
    {
        lastPage = nowPage;
        if (nowPage < TOTAL_PAGE - 1)
        {
            nowPage++;
        }
            else
            {
                nowPage = 0;
            }
        updateSlotVisibility();
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks)
    {
        super.render(guiGraphics, mouseX, mouseY, partialTicks);

        //转换为相对于GUI的坐标
        int relX = mouseX - leftPos;
        int relY = mouseY - topPos;

        //更新按钮悬停状态
        prevButtonHovered = isInPrevButtonArea(relX, relY);
        nextButtonHovered = isInNextButtonArea(relX, relY);

        //显示页码
        guiGraphics.drawString(this.font, String.format("%02d", (nowPage + 1)) + "/" + String.format("%02d", TOTAL_PAGE), leftPos + PAGE_TEXT_X, topPos + PAGE_TEXT_Y, 0x404040, false);

        //渲染工具提示（”上一页“和”下一页“）
        renderTooltips(guiGraphics, mouseX, mouseY);
    }

    //渲染工具提示（”上一页“和”下一页“）
    private void renderTooltips(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if (prevButtonHovered)
        {
            guiGraphics.renderTooltip(this.font, Component.translatable("gui.infinitypatternprovider.prev_page"), mouseX, mouseY);
            guiGraphics.blit(PREV_BUTTON_HOVER, this.leftPos + PREV_BUTTON_AREA_START_X, this.topPos + PREV_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
        }
        else
            if (nextButtonHovered)
            {
                guiGraphics.renderTooltip(this.font, Component.translatable("gui.infinitypatternprovider.next_page"), mouseX, mouseY);
                guiGraphics.blit(NEXT_BUTTON_HOVER, this.leftPos + NEXT_BUTTON_AREA_START_X, this.topPos + NEXT_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
            }
                else
                {
                    guiGraphics.blit(PREV_BUTTON_NORMAL, this.leftPos + PREV_BUTTON_AREA_START_X, this.topPos + PREV_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
                    guiGraphics.blit(NEXT_BUTTON_NORMAL, this.leftPos + NEXT_BUTTON_AREA_START_X, this.topPos + NEXT_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
                }
    }

    //检查是否在上一页按钮区域内
    private boolean isInPrevButtonArea(int relX, int relY)
    {
        return relX >= PREV_BUTTON_AREA_START_X && relX <= PREV_BUTTON_AREA_FINAL_X && relY >= PREV_BUTTON_AREA_START_Y && relY <= PREV_BUTTON_AREA_FINAL_Y;
    }

    //检查是否在下一页按钮区域内
    private boolean isInNextButtonArea(int relX, int relY)
    {
        return relX >= NEXT_BUTTON_AREA_START_X && relX <= NEXT_BUTTON_AREA_FINAL_X && relY >= NEXT_BUTTON_AREA_START_Y && relY <= NEXT_BUTTON_AREA_FINAL_Y;
    }

    //检查是否在滚轮区域内
    private boolean isInWheelArea(int relX, int relY)
    {
        return relX >= WHEEL_AREA_START_X && relX <= WHEEL_AREA_FINAL_X && relY >= WHEEL_AREA_START_Y && relY <= WHEEL_AREA_FINAL_Y;
    }

    //播放按钮点击声音
    private void playButtonClickSound()
    {
        Minecraft.getInstance().getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.0F));
    }
}