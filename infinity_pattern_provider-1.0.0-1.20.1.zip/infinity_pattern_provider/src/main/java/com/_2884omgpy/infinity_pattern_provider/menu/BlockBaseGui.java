package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.block.AEBaseEntityBlock;
import appeng.blockentity.AEBaseBlockEntity;
import appeng.util.InteractionUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.phys.BlockHitResult;

import org.jetbrains.annotations.Nullable;

public abstract class BlockBaseGui<T extends AEBaseBlockEntity> extends AEBaseEntityBlock<T>
{
    public BlockBaseGui(BlockBehaviour.Properties props)
    {
        super(props);
    }

    @Override
    public InteractionResult onActivated(Level level, BlockPos pos, Player player, InteractionHand hand, @Nullable ItemStack Item, BlockHitResult result
    ) {
        if (InteractionUtil.isInAlternateUseMode(player))
        {
            return InteractionResult.PASS;
        }
            else
            {
                var blockEntity = this.getBlockEntity(level, pos);
                if (blockEntity != null)
                {
                    var interactionResult = check(blockEntity, Item, level, pos, result, player);
                    if (interactionResult != null)
                    {
                        return interactionResult;
                    }
                    if (!level.isClientSide())
                    {
                        this.openGui(blockEntity, player);
                    }
                    return InteractionResult.sidedSuccess(level.isClientSide());
                }
                    else
                    {
                        return InteractionResult.PASS;
                    }
            }
    }

    public abstract void openGui(BlockEntity tile, Player player);

    @Nullable
    public InteractionResult check(T tile, ItemStack stack, Level world, BlockPos pos, BlockHitResult hit, Player player)
    {
        return null;
    }

}