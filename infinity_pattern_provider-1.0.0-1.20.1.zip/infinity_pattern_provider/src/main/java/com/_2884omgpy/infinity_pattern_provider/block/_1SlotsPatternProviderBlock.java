package com._2884omgpy.infinity_pattern_provider.block;

import appeng.block.crafting.PushDirection;
import appeng.menu.locator.MenuLocators;
import appeng.util.InteractionUtil;
import appeng.util.Platform;
import com._2884omgpy.infinity_pattern_provider.blockentity._1SlotsPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.menu.BlockBaseGui;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.NotNull;

import javax.annotation.Nonnull;

import static appeng.block.crafting.PatternProviderBlock.PUSH_DIRECTION;

public class _1SlotsPatternProviderBlock extends BlockBaseGui<_1SlotsPatternProviderBlockEntity>
{
    public _1SlotsPatternProviderBlock()
    {
        super(metalProps());
        this.registerDefaultState(this.defaultBlockState().setValue(PUSH_DIRECTION, PushDirection.ALL));
    }

    //添加push方向
    @Override
    protected void createBlockStateDefinition(@Nonnull StateDefinition.Builder<Block, BlockState> builder)
    {
        super.createBlockStateDefinition(builder);
        builder.add(PUSH_DIRECTION);
    }

    //检测周围方块更新
    @Override
    public void neighborChanged(@NotNull BlockState state, @NotNull Level level, @NotNull BlockPos pos, @NotNull Block block, @NotNull BlockPos fromPos, boolean isMoving)
    {
        var be = this.getBlockEntity(level, pos);
        if (be != null)
        {
            be.getLogic().updateRedstoneState();
        }
    }

    //交互结果
    @Override
    public InteractionResult check(_1SlotsPatternProviderBlockEntity tile, ItemStack stack, Level world, BlockPos pos, BlockHitResult hit, Player player)
    {
        if (stack != null && InteractionUtil.canWrenchRotate(stack))
        {
            this.setSide(world, pos, hit.getDirection());
            return InteractionResult.sidedSuccess(world.isClientSide());
        }
        return null;
    }

    //打开GUI
    @Override
    public void openGui(BlockEntity blockEntity, Player player)
    {
        if (blockEntity instanceof _1SlotsPatternProviderBlockEntity patternProvider)
        {
            patternProvider.openMenu(player, MenuLocators.forBlockEntity(patternProvider));
        }
    }

    //设置方向
    public void setSide(Level level, BlockPos pos, Direction facing)
    {
        var currentState = level.getBlockState(pos);
        var pushSide = currentState.getValue(PUSH_DIRECTION).getDirection();

        PushDirection newPushDirection;
        if (pushSide == facing.getOpposite())   //背对>>>面对
        {
            newPushDirection = PushDirection.fromDirection(facing);
        }
        else
        if (pushSide == facing)             //面对>>>全部
        {
            newPushDirection = PushDirection.ALL;
        }
        else
        if (pushSide == null)           //无方向>>>背对
        {
            newPushDirection = PushDirection.fromDirection(facing.getOpposite());
        }
        else                        //旋转
        {
            newPushDirection = PushDirection.fromDirection(Platform.rotateAround(pushSide, facing));
        }

        //方块更新
        level.setBlockAndUpdate(pos, currentState.setValue(PUSH_DIRECTION, newPushDirection));
    }
}