package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.helpers.patternprovider.PatternProviderLogicHost;
import appeng.menu.implementations.MenuTypeBuilder;
import appeng.menu.implementations.PatternProviderMenu;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.MenuType;

public class _32SlotsPatternProviderMenu extends PatternProviderMenu
{
    public static MenuType<_32SlotsPatternProviderMenu> TYPE;

    public static void init()
    {
        if (TYPE == null)
        {
            TYPE = MenuTypeBuilder.create(_32SlotsPatternProviderMenu::new, PatternProviderLogicHost.class).build("_32slots_pattern_provider");
        }
    }

    public _32SlotsPatternProviderMenu(int id, Inventory playerInventory, PatternProviderLogicHost host)
    {
        super(TYPE, id, playerInventory, host);
    }
}