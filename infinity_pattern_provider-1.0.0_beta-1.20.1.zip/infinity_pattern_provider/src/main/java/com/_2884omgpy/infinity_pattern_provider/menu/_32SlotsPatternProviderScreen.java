package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.client.gui.implementations.PatternProviderScreen;
import appeng.client.gui.style.ScreenStyle;
import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class _32SlotsPatternProviderScreen extends PatternProviderScreen<_32SlotsPatternProviderMenu>
{
    private static final ResourceLocation NEXT_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/next_button_hover.png");
    private static final ResourceLocation NEXT_BUTTON_NORMAL = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/next_button_normal.png");
    private static final ResourceLocation PREV_BUTTON_HOVER = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/prev_button_hover.png");
    private static final ResourceLocation PREV_BUTTON_NORMAL = ResourceLocation.fromNamespaceAndPath(InfinityPatternProvider.MOD_ID, "textures/gui/prev_button_normal.png");

    private static final int BUTTON_HEIGHT = 15;
    private static final int BUTTON_WIDTH = 22;

    private static final int PREV_BUTTON_AREA_START_X = 101;
    private static final int PREV_BUTTON_AREA_START_Y = 97;
    private static final int PREV_BUTTON_AREA_FINAL_X = PREV_BUTTON_AREA_START_X + BUTTON_WIDTH;
    private static final int PREV_BUTTON_AREA_FINAL_Y = PREV_BUTTON_AREA_START_Y + BUTTON_HEIGHT;

    private static final int NEXT_BUTTON_AREA_START_X = 143;
    private static final int NEXT_BUTTON_AREA_START_Y = 97;
    private static final int NEXT_BUTTON_AREA_FINAL_X = NEXT_BUTTON_AREA_START_X + BUTTON_WIDTH;
    private static final int NEXT_BUTTON_AREA_FINAL_Y = NEXT_BUTTON_AREA_START_Y + BUTTON_HEIGHT;

    private boolean prevButtonHovered = false;
    private boolean nextButtonHovered = false;



    public _32SlotsPatternProviderScreen(_32SlotsPatternProviderMenu menu, Inventory playerInventory, Component title, ScreenStyle style)
    {
        super(menu, playerInventory, title, style);
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks)
    {
        super.render(guiGraphics, mouseX, mouseY, partialTicks);

        //转换为相对于GUI的坐标
        int relX = mouseX - leftPos;
        int relY = mouseY - topPos;

        //更新按钮悬停状态
        prevButtonHovered = isInPrevButtonArea(relX, relY);
        nextButtonHovered = isInNextButtonArea(relX, relY);

        //渲染工具提示（”上一页“和”下一页“）
        renderTooltips(guiGraphics, mouseX, mouseY);
    }

    //渲染工具提示（”上一页“和”下一页“）
    private void renderTooltips(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if (prevButtonHovered)
        {
            guiGraphics.renderTooltip(this.font, Component.translatable("gui.infinitypatternprovider.prev_page"), mouseX, mouseY);
            guiGraphics.blit(PREV_BUTTON_HOVER, this.leftPos + PREV_BUTTON_AREA_START_X, this.topPos + PREV_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
        }
        else
            if (nextButtonHovered)
            {
                guiGraphics.renderTooltip(this.font, Component.translatable("gui.infinitypatternprovider.next_page"), mouseX, mouseY);
                guiGraphics.blit(NEXT_BUTTON_HOVER, this.leftPos + NEXT_BUTTON_AREA_START_X, this.topPos + NEXT_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
            }
                else
                {
                    guiGraphics.blit(PREV_BUTTON_NORMAL, this.leftPos + PREV_BUTTON_AREA_START_X, this.topPos + PREV_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
                    guiGraphics.blit(NEXT_BUTTON_NORMAL, this.leftPos + NEXT_BUTTON_AREA_START_X, this.topPos + NEXT_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
                }
    }

    //检查是否在上一页按钮区域内
    private boolean isInPrevButtonArea(int relX, int relY)
    {
        return relX >= PREV_BUTTON_AREA_START_X && relX <= PREV_BUTTON_AREA_FINAL_X && relY >= PREV_BUTTON_AREA_START_Y && relY <= PREV_BUTTON_AREA_FINAL_Y;
    }

    //检查是否在下一页按钮区域内
    private boolean isInNextButtonArea(int relX, int relY)
    {
        return relX >= NEXT_BUTTON_AREA_START_X && relX <= NEXT_BUTTON_AREA_FINAL_X && relY >= NEXT_BUTTON_AREA_START_Y && relY <= NEXT_BUTTON_AREA_FINAL_Y;
    }
}