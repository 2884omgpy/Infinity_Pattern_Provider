package com._2884omgpy.infinity_pattern_provider;

import com._2884omgpy.infinity_pattern_provider.init.*;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(InfinityPatternProvider.MOD_ID)
public class InfinityPatternProvider
{
    public static final String MOD_ID = "infinitypatternprovider";
    public static InfinityPatternProvider INSTANCE;

    public InfinityPatternProvider(FMLJavaModLoadingContext context)
    {
        INSTANCE = this;
        IEventBus modEventBus = context.getModEventBus();

        ModBlocks.register(modEventBus);            //方块注册
        ModItems.register(modEventBus);             //物品注册
        ModBlockEntities.register(modEventBus);     //方块实体注册
        ModCreativeModeTabs.register(modEventBus);  //创造模式物品栏注册

        RegistryHandler.init();                     //在RegistryHandler中注册菜单

        modEventBus.addListener(this::commonSetup);
        MinecraftForge.EVENT_BUS.register(this);
        context.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    //在这里输入通用设置代码
    private void commonSetup(final FMLCommonSetupEvent event)
    {
        event.enqueueWork(() -> ModMenus.register());    // 注册菜单
        BindBlockAndBlockEntity.bindAll();              //绑定方块和方块实体
    }

    //服务器启动时执行某些操作
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event)
    {

    }
}
