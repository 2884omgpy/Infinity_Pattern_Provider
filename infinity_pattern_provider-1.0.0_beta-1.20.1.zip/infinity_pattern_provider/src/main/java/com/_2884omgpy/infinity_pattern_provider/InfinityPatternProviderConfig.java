package com._2884omgpy.infinity_pattern_provider;

import net.minecraftforge.common.ForgeConfigSpec;

public class InfinityPatternProviderConfig
{

    public static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue PATTERN_CAPACITY;
    public static final ForgeConfigSpec.IntValue PAGE_SIZE;
    public static final ForgeConfigSpec.BooleanValue OPTIMIZE_NBT;

    static
    {
        BUILDER.push("infinity_pattern_provider");

        PATTERN_CAPACITY = BUILDER
                .comment("Maximum number of patterns that can be stored (default: 32768)")
                .defineInRange("patternCapacity", 32768, 512, 131072);

        PAGE_SIZE = BUILDER
                .comment("Number of patterns per page in GUI (default: 512, must be multiple of 32)")
                .defineInRange("pageSize", 512, 32, 2048);

        OPTIMIZE_NBT = BUILDER
                .comment("Enable optimized NBT storage (reduces file size but may be incompatible with other mods)")
                .define("optimizeNBT", true);

        BUILDER.pop();
        SPEC = BUILDER.build();
    }
}