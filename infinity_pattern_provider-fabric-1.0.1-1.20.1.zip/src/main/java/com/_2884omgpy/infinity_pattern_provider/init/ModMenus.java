package com._2884omgpy.infinity_pattern_provider.init;

import com._2884omgpy.infinity_pattern_provider.menu.InfinityPatternProviderMenu;
import com._2884omgpy.infinity_pattern_provider.menu._1024SlotsPatternProviderMenu;
import com._2884omgpy.infinity_pattern_provider.menu._1SlotsPatternProviderMenu;
import com._2884omgpy.infinity_pattern_provider.menu._32SlotsPatternProviderMenu;

public class ModMenus
{
    public static void register()
    {
        _1SlotsPatternProviderMenu.init();
        _32SlotsPatternProviderMenu.init();
        _1024SlotsPatternProviderMenu.init();
        InfinityPatternProviderMenu.init();
    }
}