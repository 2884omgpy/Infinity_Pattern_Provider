package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.client.gui.implementations.PatternProviderScreen;
import appeng.client.gui.style.ScreenStyle;
import appeng.menu.slot.AppEngSlot;
import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

import java.util.List;

public class _32SlotsPatternProviderScreen extends PatternProviderScreen<_32SlotsPatternProviderMenu>
{
    private static final ResourceLocation NEXT_BUTTON_HOVER = new ResourceLocation(InfinityPatternProvider.MOD_ID, "textures/gui/next_button_hover.png");
    private static final ResourceLocation PREV_BUTTON_HOVER = new ResourceLocation(InfinityPatternProvider.MOD_ID, "textures/gui/prev_button_hover.png");

    private static final int START_X = 8;
    private static final int START_Y = 42;

    private static final int BUTTON_HEIGHT = 22;
    private static final int BUTTON_WIDTH = 15;

    private static final int PREV_BUTTON_AREA_START_X = 154;
    private static final int PREV_BUTTON_AREA_START_Y = 41;
    private static final int PREV_BUTTON_AREA_FINAL_X = PREV_BUTTON_AREA_START_X + BUTTON_WIDTH;
    private static final int PREV_BUTTON_AREA_FINAL_Y = PREV_BUTTON_AREA_START_Y + BUTTON_HEIGHT;

    private static final int NEXT_BUTTON_AREA_START_X = 154;
    private static final int NEXT_BUTTON_AREA_START_Y = 91;
    private static final int NEXT_BUTTON_AREA_FINAL_X = NEXT_BUTTON_AREA_START_X + BUTTON_WIDTH;
    private static final int NEXT_BUTTON_AREA_FINAL_Y = NEXT_BUTTON_AREA_START_Y + BUTTON_HEIGHT;

    private List<AppEngSlot> patternSlots;

    public _32SlotsPatternProviderScreen(_32SlotsPatternProviderMenu menu, Inventory playerInventory, Component title, ScreenStyle style)
    {
        super(menu, playerInventory, title, style);
        this.patternSlots = menu.getPatternSlots();
    }

    @Override
    protected void init()
    {
        super.init();
        updateAllSlotPositions();
    }

    //更新所有槽位的位置
    private void updateAllSlotPositions()
    {
        if (patternSlots == null || patternSlots.isEmpty())
        {
            return;
        }

        for (int i = 0; i < patternSlots.size(); i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            setSlotPosition(slot, i);
        }
    }

    //设置槽位位置
    @SuppressWarnings("java:S3011") //抑制java警告
    private void setSlotPosition(AppEngSlot slot, int slotIndex)
    {
        int row = (slotIndex % 32) / 8;
        int col = (slotIndex % 32) % 8;

        int x = START_X + col * 18;
        int y = START_Y + row * 18;

        //x和y变量已经在访问变换器中强制去除了final修饰符，实际上可以正常使用
        slot.x = x;
        slot.y = y;

        //强制更新槽位状态
        slot.setChanged();
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks)
    {
        super.render(guiGraphics, mouseX, mouseY, partialTicks);

        //渲染工具提示（”上一页“和”下一页“）
        renderTooltips(guiGraphics, mouseX, mouseY);
    }

    //渲染工具提示（”上一页“和”下一页“）
    private void renderTooltips(GuiGraphics guiGraphics, int mouseX, int mouseY)
    {
        if (isInPrevButtonArea(mouseX - leftPos, mouseY - topPos))
        {
            guiGraphics.renderTooltip(this.font, Component.translatable("gui.infinitypatternprovider.prev_page"), mouseX, mouseY);
            guiGraphics.blit(PREV_BUTTON_HOVER, this.leftPos + PREV_BUTTON_AREA_START_X, this.topPos + PREV_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
        }
        else
            if (isInNextButtonArea(mouseX - leftPos, mouseY - topPos))
            {
                guiGraphics.renderTooltip(this.font, Component.translatable("gui.infinitypatternprovider.next_page"), mouseX, mouseY);
                guiGraphics.blit(NEXT_BUTTON_HOVER, this.leftPos + NEXT_BUTTON_AREA_START_X, this.topPos + NEXT_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
            }
    }

    //检查是否在上一页按钮区域内
    private boolean isInPrevButtonArea(int relX, int relY)
    {
        return relX >= PREV_BUTTON_AREA_START_X && relX <= PREV_BUTTON_AREA_FINAL_X && relY >= PREV_BUTTON_AREA_START_Y && relY <= PREV_BUTTON_AREA_FINAL_Y;
    }

    //检查是否在下一页按钮区域内
    private boolean isInNextButtonArea(int relX, int relY)
    {
        return relX >= NEXT_BUTTON_AREA_START_X && relX <= NEXT_BUTTON_AREA_FINAL_X && relY >= NEXT_BUTTON_AREA_START_Y && relY <= NEXT_BUTTON_AREA_FINAL_Y;
    }
}