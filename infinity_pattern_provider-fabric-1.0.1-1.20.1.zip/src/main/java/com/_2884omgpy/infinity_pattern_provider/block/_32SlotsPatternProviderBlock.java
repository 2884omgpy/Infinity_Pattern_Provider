package com._2884omgpy.infinity_pattern_provider.block;

import appeng.block.crafting.PushDirection;
import appeng.menu.locator.MenuLocators;
import appeng.util.InteractionUtil;
import appeng.util.Platform;
import com._2884omgpy.infinity_pattern_provider.blockentity._32SlotsPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.menu.BlockBaseGui;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.NotNull;

import static appeng.block.crafting.PatternProviderBlock.PUSH_DIRECTION;

public class _32SlotsPatternProviderBlock extends BlockBaseGui<_32SlotsPatternProviderBlockEntity>
{
    public _32SlotsPatternProviderBlock()
    {
        super(metalProps());
        this.registerDefaultState(this.defaultBlockState().setValue(PUSH_DIRECTION, PushDirection.ALL));
    }

    //添加push方向
    @Override
    protected void createBlockStateDefinition(@NotNull StateDefinition.Builder<Block, BlockState> builder)
    {
        super.createBlockStateDefinition(builder);
        builder.add(PUSH_DIRECTION);
    }

    //检测周围方块更新
    @Override
    public void neighborChanged(@NotNull BlockState blockState, @NotNull Level level, @NotNull BlockPos blockPosition, @NotNull Block block, @NotNull BlockPos fromPosition, boolean isMoving)
    {
        var blockEntity = this.getBlockEntity(level, blockPosition);
        if (blockEntity != null)
        {
            blockEntity.getLogic().updateRedstoneState();
        }
    }

    //交互结果
    @Override
    public InteractionResult check(_32SlotsPatternProviderBlockEntity blockEntity, ItemStack itemStack, Level world, BlockPos blockPosition, BlockHitResult blockHitResult, Player player)
    {
        if (itemStack != null && InteractionUtil.canWrenchRotate(itemStack))
        {
            this.setSide(world, blockPosition, blockHitResult.getDirection());
            return InteractionResult.sidedSuccess(world.isClientSide());
        }
        return null;
    }

    //打开GUI
    @Override
    public void openGui(BlockEntity blockEntity, Player player)
    {
        if (blockEntity instanceof _32SlotsPatternProviderBlockEntity patternProvider)
        {
            patternProvider.openMenu(player, MenuLocators.forBlockEntity(patternProvider));
        }
    }

    //设置方向
    public void setSide(Level level, BlockPos blockPosition, Direction facingDirection)
    {
        var currentState = level.getBlockState(blockPosition);
        var pushSide = currentState.getValue(PUSH_DIRECTION).getDirection();

        PushDirection newPushDirection;
        if (pushSide == facingDirection.getOpposite())   //背对>>>面对
        {
            newPushDirection = PushDirection.fromDirection(facingDirection);
        }
        else
            if (pushSide == facingDirection)             //面对>>>全部
            {
                newPushDirection = PushDirection.ALL;
            }
            else
                if (pushSide == null)                   //无方向>>>背对
                {
                    newPushDirection = PushDirection.fromDirection(facingDirection.getOpposite());
                }
                    else                                //旋转
                    {
                        newPushDirection = PushDirection.fromDirection(Platform.rotateAround(pushSide, facingDirection));
                    }

        //方块更新
        level.setBlockAndUpdate(blockPosition, currentState.setValue(PUSH_DIRECTION, newPushDirection));
    }
}