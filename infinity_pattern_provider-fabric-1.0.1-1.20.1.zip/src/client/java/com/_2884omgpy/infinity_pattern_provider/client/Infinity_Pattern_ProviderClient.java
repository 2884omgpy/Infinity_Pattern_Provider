package com._2884omgpy.infinity_pattern_provider.client;

import net.fabricmc.api.ClientModInitializer;

public class Infinity_Pattern_ProviderClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// This entrypoint is suitable for setting up client-specific logic, such as rendering.
	}
}