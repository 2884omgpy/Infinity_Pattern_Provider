package com._2884omgpy.infinity_pattern_provider.blockentity;

import appeng.api.stacks.AEItemKey;
import appeng.blockentity.crafting.PatternProviderBlockEntity;
import appeng.helpers.patternprovider.PatternProviderLogic;
import appeng.menu.ISubMenu;
import appeng.menu.MenuOpener;
import appeng.menu.locator.MenuLocator;
import com._2884omgpy.infinity_pattern_provider.init.ModBlockEntities;
import com._2884omgpy.infinity_pattern_provider.init.ModBlocks;
import com._2884omgpy.infinity_pattern_provider.menu._32SlotsPatternProviderMenu;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class _32SlotsPatternProviderBlockEntity extends PatternProviderBlockEntity
{
    public _32SlotsPatternProviderBlockEntity(class_2338 pos, class_2680 blockState)
    {
        super(ModBlockEntities._32SLOTS_PATTERN_PROVIDER, pos, blockState);
    }

    //设置样板供应器槽位数量
    @Override
    protected PatternProviderLogic createLogic()
    {
        return new PatternProviderLogic(this.getMainNode(), this, 32);
    }

    //打开菜单
    @Override
    public void openMenu(class_1657 player, MenuLocator locator)
    {
        MenuOpener.open(_32SlotsPatternProviderMenu.TYPE, player, locator);
    }

    //返回至主菜单
    @Override
    public void returnToMainMenu(class_1657 player, ISubMenu subMenu)
    {
        MenuOpener.returnTo(_32SlotsPatternProviderMenu.TYPE, player, subMenu.getLocator());
    }

    //获取返回主菜单按键图标
    @Override
    public class_1799 getMainMenuIcon()
    {
        return new class_1799(ModBlocks._32SLOTS_PATTERN_PROVIDER);
    }

    //获取终端图标
    @Override
    public AEItemKey getTerminalIcon()
    {
        return AEItemKey.of(ModBlocks._32SLOTS_PATTERN_PROVIDER);
    }

    //设置在网络信息界面中显示的图标为当前方块物品
    @Override
    public void onReady()
    {
        super.onReady();
        this.getMainNode().setVisualRepresentation(new class_1799(ModBlocks._32SLOTS_PATTERN_PROVIDER));
    }
}