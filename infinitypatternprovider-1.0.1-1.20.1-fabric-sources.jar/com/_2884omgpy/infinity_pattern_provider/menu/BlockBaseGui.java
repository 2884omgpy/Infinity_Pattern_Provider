package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.block.AEBaseEntityBlock;
import appeng.blockentity.AEBaseBlockEntity;
import appeng.util.InteractionUtil;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import org.jetbrains.annotations.Nullable;

public abstract class BlockBaseGui<T extends AEBaseBlockEntity> extends AEBaseEntityBlock<T>
{
    public BlockBaseGui(class_4970.class_2251 props)
    {
        super(props);
    }

    @Override
    public class_1269 onActivated(class_1937 level, class_2338 pos, class_1657 player, class_1268 hand, @Nullable class_1799 Item, class_3965 result)
    {
        if (InteractionUtil.isInAlternateUseMode(player))
        {
            return class_1269.field_5811;
        }
            else
            {
                var blockEntity = this.getBlockEntity(level, pos);
                if (blockEntity != null)
                {
                    var interactionResult = check(blockEntity, Item, level, pos, result, player);
                    if (interactionResult != null)
                    {
                        return interactionResult;
                    }
                    if (!level.method_8608())
                    {
                        this.openGui(blockEntity, player);
                    }
                    return class_1269.method_29236(level.method_8608());
                }
                    else
                    {
                        return class_1269.field_5811;
                    }
            }
    }

    public abstract void openGui(class_2586 tile, class_1657 player);

    @Nullable
    public class_1269 check(T tile, class_1799 stack, class_1937 world, class_2338 pos, class_3965 hit, class_1657 player)
    {
        return null;
    }

}