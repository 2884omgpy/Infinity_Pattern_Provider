package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.helpers.patternprovider.PatternProviderLogicHost;
import appeng.menu.implementations.MenuTypeBuilder;
import appeng.menu.implementations.PatternProviderMenu;
import net.minecraft.class_1661;
import net.minecraft.class_3917;

public class _1SlotsPatternProviderMenu extends PatternProviderMenu
{
    public static class_3917<_1SlotsPatternProviderMenu> TYPE;

    public static void init()
    {
        if (TYPE == null)
        {
            TYPE = MenuTypeBuilder.create(_1SlotsPatternProviderMenu::new, PatternProviderLogicHost.class).build("_1slots_pattern_provider");
        }
    }

    public _1SlotsPatternProviderMenu(int id, class_1661 playerInventory, PatternProviderLogicHost host)
    {
        super(TYPE, id, playerInventory, host);
    }
}
