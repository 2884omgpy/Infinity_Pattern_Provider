package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.client.gui.implementations.PatternProviderScreen;
import appeng.client.gui.style.ScreenStyle;
import net.minecraft.class_1661;
import net.minecraft.class_2561;

public class _1SlotsPatternProviderScreen extends PatternProviderScreen<_1SlotsPatternProviderMenu>
{
    public _1SlotsPatternProviderScreen(_1SlotsPatternProviderMenu menu, class_1661 playerInventory, class_2561 title, ScreenStyle style)
    {
        super(menu, playerInventory, title, style);
    }
}
