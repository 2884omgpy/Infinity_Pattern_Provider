package com._2884omgpy.infinity_pattern_provider.menu;

import appeng.client.gui.implementations.PatternProviderScreen;
import appeng.client.gui.style.ScreenStyle;
import appeng.menu.slot.AppEngSlot;
import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import java.util.List;
import net.minecraft.class_1109;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;

public class InfinityPatternProviderScreen extends PatternProviderScreen<InfinityPatternProviderMenu>
{
    private static final class_2960 NEXT_BUTTON_HOVER = new class_2960(InfinityPatternProvider.MOD_ID, "textures/gui/next_button_hover.png");
    private static final class_2960 PREV_BUTTON_HOVER = new class_2960(InfinityPatternProvider.MOD_ID, "textures/gui/prev_button_hover.png");

    private static final int START_X = 8;
    private static final int START_Y = 42;

    private static final int BUTTON_HEIGHT = 22;
    private static final int BUTTON_WIDTH = 15;

    private static final int PREV_BUTTON_AREA_START_X = 154;
    private static final int PREV_BUTTON_AREA_START_Y = 41;
    private static final int PREV_BUTTON_AREA_FINAL_X = PREV_BUTTON_AREA_START_X + BUTTON_WIDTH;
    private static final int PREV_BUTTON_AREA_FINAL_Y = PREV_BUTTON_AREA_START_Y + BUTTON_HEIGHT;

    private static final int NEXT_BUTTON_AREA_START_X = 154;
    private static final int NEXT_BUTTON_AREA_START_Y = 91;
    private static final int NEXT_BUTTON_AREA_FINAL_X = NEXT_BUTTON_AREA_START_X + BUTTON_WIDTH;
    private static final int NEXT_BUTTON_AREA_FINAL_Y = NEXT_BUTTON_AREA_START_Y + BUTTON_HEIGHT;

    private static final int WHEEL_AREA_START_X = 7;
    private static final int WHEEL_AREA_START_Y = 41;
    private static final int WHEEL_AREA_FINAL_X = 168;
    private static final int WHEEL_AREA_FINAL_Y = 112;

    private static final int PAGE_TEXT_X = 116;
    private static final int PAGE_TEXT_Y = 28;

    private static final int SLOTS_PER_PAGE = 32;
    private static final int TOTAL_PAGE = 1024;
    private int nowPage = 0;
    private int lastPage = 1;
    private List<AppEngSlot> patternSlots;

    public InfinityPatternProviderScreen(InfinityPatternProviderMenu menu, class_1661 playerInventory, class_2561 title, ScreenStyle style)
    {
        super(menu, playerInventory, title, style);
        this.patternSlots = menu.getPatternSlots();

        for(int i = SLOTS_PER_PAGE ; i < SLOTS_PER_PAGE * TOTAL_PAGE ; i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            slot.setActive(false);
        }
    }

    @Override
    protected void method_25426()
    {
        super.method_25426();
        updateAllSlotPositions();
    }

    //更新所有槽位的位置
    private void updateAllSlotPositions()
    {
        if (patternSlots == null || patternSlots.isEmpty())
        {
            return;
        }

        for (int i = 0; i < patternSlots.size(); i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            setSlotPosition(slot, i);
        }
    }

    //设置槽位位置
    @SuppressWarnings("java:S3011") //抑制java警告
    private void setSlotPosition(AppEngSlot slot, int slotIndex)
    {
        int row = (slotIndex % 32) / 8;
        int col = (slotIndex % 32) % 8;

        int x = START_X + col * 18;
        int y = START_Y + row * 18;

        //x和y变量已经在访问加宽器中强制去除了final修饰符，实际上可以正常使用
        slot.field_7873 = x;
        slot.field_7872 = y;

        //强制更新槽位状态
        slot.method_7668();
    }

    //更新槽位可见性
    private void updateSlotVisibility()
    {
        if (patternSlots == null || patternSlots.isEmpty())
        {
            return;
        }

        PageSlotsUnVisible(lastPage);
        PageSlotsVisible(nowPage);
    }

    private void PageSlotsVisible(int page)
    {
        for(int i = SLOTS_PER_PAGE * page ; i < SLOTS_PER_PAGE * page + SLOTS_PER_PAGE ; i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            slot.setActive(true);
        }
    }

    private void PageSlotsUnVisible(int page)
    {
        for(int i = SLOTS_PER_PAGE * page ; i < SLOTS_PER_PAGE * page + SLOTS_PER_PAGE ; i++)
        {
            AppEngSlot slot = patternSlots.get(i);
            slot.setActive(false);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button)
    {
        int relX = (int) (mouseX - field_2776);
        int relY = (int) (mouseY - field_2800);

        if (isInPrevButtonArea(relX, relY) && button == 0)
        {
            prevPage();
            playButtonClickSound();
            return true;
        }
        else
            if (isInNextButtonArea(relX, relY) && button == 0)
            {
                nextPage();
                playButtonClickSound();
                return true;
            }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double delta)
    {
        int relX = (int) (mouseX - field_2776);
        int relY = (int) (mouseY - field_2800);

        if (isInWheelArea(relX, relY))
        {
            if (delta > 0)
            {
                prevPage();
            }
            else
                if (delta < 0)
                {
                    nextPage();
                }
            return true;
        }
        return super.method_25401(mouseX, mouseY, delta);
    }

    //上一页
    public void prevPage()
    {
        lastPage = nowPage;
        if (nowPage > 0)
        {
            nowPage--;
        }
            else
            {
                nowPage = TOTAL_PAGE - 1;
            }
        updateSlotVisibility();
    }

    //下一页
    public void nextPage()
    {
        lastPage = nowPage;
        if (nowPage < TOTAL_PAGE - 1)
        {
            nowPage++;
        }
            else
            {
                nowPage = 0;
            }
        updateSlotVisibility();
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks)
    {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTicks);

        //显示页码
        guiGraphics.method_51433(this.field_22793, String.format("%04d", (nowPage + 1)) + "/" + String.format("%04d", TOTAL_PAGE), field_2776 + PAGE_TEXT_X, field_2800 + PAGE_TEXT_Y, 0x404040, false);

        //渲染工具提示（”上一页“和”下一页“）
        renderTooltips(guiGraphics, mouseX, mouseY);
    }

    //渲染工具提示（”上一页“和”下一页“）
    private void renderTooltips(class_332 guiGraphics, int mouseX, int mouseY)
    {
        if (isInPrevButtonArea(mouseX - field_2776, mouseY - field_2800))
        {
            guiGraphics.method_51438(this.field_22793, class_2561.method_43471("gui.infinitypatternprovider.prev_page"), mouseX, mouseY);
            guiGraphics.method_25290(PREV_BUTTON_HOVER, this.field_2776 + PREV_BUTTON_AREA_START_X, this.field_2800 + PREV_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
        }
        else
            if (isInNextButtonArea(mouseX - field_2776, mouseY - field_2800))
            {
                guiGraphics.method_51438(this.field_22793, class_2561.method_43471("gui.infinitypatternprovider.next_page"), mouseX, mouseY);
                guiGraphics.method_25290(NEXT_BUTTON_HOVER, this.field_2776 + NEXT_BUTTON_AREA_START_X, this.field_2800 + NEXT_BUTTON_AREA_START_Y, 0, 0, BUTTON_WIDTH, BUTTON_HEIGHT, BUTTON_WIDTH, BUTTON_HEIGHT);
            }
    }

    //检查是否在上一页按钮区域内
    private boolean isInPrevButtonArea(int relX, int relY)
    {
        return relX >= PREV_BUTTON_AREA_START_X && relX <= PREV_BUTTON_AREA_FINAL_X && relY >= PREV_BUTTON_AREA_START_Y && relY <= PREV_BUTTON_AREA_FINAL_Y;
    }

    //检查是否在下一页按钮区域内
    private boolean isInNextButtonArea(int relX, int relY)
    {
        return relX >= NEXT_BUTTON_AREA_START_X && relX <= NEXT_BUTTON_AREA_FINAL_X && relY >= NEXT_BUTTON_AREA_START_Y && relY <= NEXT_BUTTON_AREA_FINAL_Y;
    }

    //检查是否在滚轮区域内
    private boolean isInWheelArea(int relX, int relY)
    {
        return relX >= WHEEL_AREA_START_X && relX <= WHEEL_AREA_FINAL_X && relY >= WHEEL_AREA_START_Y && relY <= WHEEL_AREA_FINAL_Y;
    }

    //播放按钮点击声音
    private void playButtonClickSound()
    {
        class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, 1.0F));
    }
}