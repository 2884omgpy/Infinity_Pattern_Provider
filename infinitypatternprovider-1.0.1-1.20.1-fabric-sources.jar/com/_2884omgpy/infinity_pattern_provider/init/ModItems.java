package com._2884omgpy.infinity_pattern_provider.init;

import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import com._2884omgpy.infinity_pattern_provider.part.InfinityPatternProviderPart;
import com._2884omgpy.infinity_pattern_provider.part._1024SlotsPatternProviderPart;
import com._2884omgpy.infinity_pattern_provider.part._1SlotsPatternProviderPart;
import com._2884omgpy.infinity_pattern_provider.part._32SlotsPatternProviderPart;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import appeng.items.parts.PartItem;

public class ModItems
{
    public static final class_1792 _1SLOTS_PATTERN_PROVIDER_PART = new PartItem<>(new class_1792.class_1793(), _1SlotsPatternProviderPart.class, _1SlotsPatternProviderPart::new);
    public static final class_1792 _32SLOTS_PATTERN_PROVIDER_PART = new PartItem<>(new class_1792.class_1793(), _32SlotsPatternProviderPart.class, _32SlotsPatternProviderPart::new);
    public static final class_1792 _1024SLOTS_PATTERN_PROVIDER_PART = new PartItem<>(new class_1792.class_1793(), _1024SlotsPatternProviderPart.class, _1024SlotsPatternProviderPart::new);
    public static final class_1792 INFINITY_PATTERN_PROVIDER_PART = new PartItem<>(new class_1792.class_1793(), InfinityPatternProviderPart.class, InfinityPatternProviderPart::new);

    public static void register()
    {
        registerItem("_1slots_pattern_provider_part", _1SLOTS_PATTERN_PROVIDER_PART);
        registerItem("_32slots_pattern_provider_part", _32SLOTS_PATTERN_PROVIDER_PART);
        registerItem("_1024slots_pattern_provider_part", _1024SLOTS_PATTERN_PROVIDER_PART);
        registerItem("infinity_pattern_provider_part", INFINITY_PATTERN_PROVIDER_PART);
    }

    private static void registerItem(String itemID, class_1792 item)
    {
        class_2378.method_10230(class_7923.field_41178, new class_2960(InfinityPatternProvider.MOD_ID, itemID), item);
    }
}