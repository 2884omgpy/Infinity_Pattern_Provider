package com._2884omgpy.infinity_pattern_provider.init;

import appeng.block.AEBaseEntityBlock;
import appeng.block.crafting.PatternProviderBlock;
import appeng.blockentity.AEBaseBlockEntity;
import appeng.blockentity.ClientTickingBlockEntity;
import appeng.blockentity.ServerTickingBlockEntity;
import appeng.blockentity.crafting.PatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.block.InfinityPatternProviderBlock;
import com._2884omgpy.infinity_pattern_provider.block._1024SlotsPatternProviderBlock;
import com._2884omgpy.infinity_pattern_provider.block._1SlotsPatternProviderBlock;
import com._2884omgpy.infinity_pattern_provider.block._32SlotsPatternProviderBlock;
import com._2884omgpy.infinity_pattern_provider.blockentity.InfinityPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.blockentity._1024SlotsPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.blockentity._1SlotsPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.blockentity._32SlotsPatternProviderBlockEntity;
import net.minecraft.class_2591;
import net.minecraft.class_5558;

public class BindBlockAndBlockEntity
{
    //绑定Block和对应的BlockEntity
    public static void bindAll()
    {
        bindBlockAndEntity((_1SlotsPatternProviderBlock) ModBlocks._1SLOTS_PATTERN_PROVIDER, ModBlockEntities._1SLOTS_PATTERN_PROVIDER, _1SlotsPatternProviderBlockEntity.class);
        bindBlockAndEntity((_32SlotsPatternProviderBlock) ModBlocks._32SLOTS_PATTERN_PROVIDER, ModBlockEntities._32SLOTS_PATTERN_PROVIDER, _32SlotsPatternProviderBlockEntity.class);
        bindBlockAndEntity((_1024SlotsPatternProviderBlock) ModBlocks._1024SLOTS_PATTERN_PROVIDER, ModBlockEntities._1024SLOTS_PATTERN_PROVIDER, _1024SlotsPatternProviderBlockEntity.class);
        bindBlockAndEntity((InfinityPatternProviderBlock) ModBlocks.INFINITY_PATTERN_PROVIDER, ModBlockEntities.INFINITY_PATTERN_PROVIDER, InfinityPatternProviderBlockEntity.class);
    }

    private static <T extends AEBaseBlockEntity> void bindBlockAndEntity(AEBaseEntityBlock<T> block, class_2591<T> blockEntityType, Class<T> blockEntityClass)
    {
        class_5558<T> serverTicker = null;
        if (ServerTickingBlockEntity.class.isAssignableFrom(blockEntityClass))
        {
            serverTicker = (level, pos, state, entity) -> ((ServerTickingBlockEntity) entity).serverTick();
        }

        class_5558<T> clientTicker = null;
        if (ClientTickingBlockEntity.class.isAssignableFrom(blockEntityClass))
        {
            clientTicker = (level, pos, state, entity) -> ((ClientTickingBlockEntity) entity).clientTick();
        }

        //使用AE2的setBlockEntity方法进行绑定
        block.setBlockEntity(blockEntityClass, blockEntityType, clientTicker, serverTicker);
    }
}
