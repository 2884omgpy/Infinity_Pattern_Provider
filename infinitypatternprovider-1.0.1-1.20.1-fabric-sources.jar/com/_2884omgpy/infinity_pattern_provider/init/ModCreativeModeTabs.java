package com._2884omgpy.infinity_pattern_provider.init;

import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModCreativeModeTabs
{
    public static final class_1761 INFINITY_PATTERN_PROVIDER_TAB = FabricItemGroup.builder().method_47320(() -> new class_1799(ModBlocks.INFINITY_PATTERN_PROVIDER)).method_47321(class_2561.method_43471("itemGroup.infinity_pattern_provider_creative_tab")).method_47317((parameters, output) ->
    {
        output.method_45421(ModBlocks._1SLOTS_PATTERN_PROVIDER);
        output.method_45421(ModBlocks._32SLOTS_PATTERN_PROVIDER);
        output.method_45421(ModBlocks._1024SLOTS_PATTERN_PROVIDER);
        output.method_45421(ModBlocks.INFINITY_PATTERN_PROVIDER);

        output.method_45421(ModItems._1SLOTS_PATTERN_PROVIDER_PART);
        output.method_45421(ModItems._32SLOTS_PATTERN_PROVIDER_PART);
        output.method_45421(ModItems._1024SLOTS_PATTERN_PROVIDER_PART);
        output.method_45421(ModItems.INFINITY_PATTERN_PROVIDER_PART);
    }).method_47324();

    public static void register()
    {
        class_2378.method_10230(class_7923.field_44687, new class_2960(InfinityPatternProvider.MOD_ID, "creative_tab"), INFINITY_PATTERN_PROVIDER_TAB);
    }
}