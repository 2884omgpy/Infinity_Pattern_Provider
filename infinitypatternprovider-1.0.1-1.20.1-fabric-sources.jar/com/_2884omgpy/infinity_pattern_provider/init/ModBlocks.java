package com._2884omgpy.infinity_pattern_provider.init;

import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import com._2884omgpy.infinity_pattern_provider.block.InfinityPatternProviderBlock;
import com._2884omgpy.infinity_pattern_provider.block._1024SlotsPatternProviderBlock;
import com._2884omgpy.infinity_pattern_provider.block._1SlotsPatternProviderBlock;
import com._2884omgpy.infinity_pattern_provider.block._32SlotsPatternProviderBlock;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlocks
{
    public static final class_2248 _1SLOTS_PATTERN_PROVIDER = new _1SlotsPatternProviderBlock();
    public static final class_2248 _32SLOTS_PATTERN_PROVIDER = new _32SlotsPatternProviderBlock();
    public static final class_2248 _1024SLOTS_PATTERN_PROVIDER = new _1024SlotsPatternProviderBlock();
    public static final class_2248 INFINITY_PATTERN_PROVIDER = new InfinityPatternProviderBlock();

    public static void register()
    {
        registerBlockWithItem("_1slots_pattern_provider", _1SLOTS_PATTERN_PROVIDER);
        registerBlockWithItem("_32slots_pattern_provider", _32SLOTS_PATTERN_PROVIDER);
        registerBlockWithItem("_1024slots_pattern_provider", _1024SLOTS_PATTERN_PROVIDER);
        registerBlockWithItem("infinity_pattern_provider", INFINITY_PATTERN_PROVIDER);
    }

    private static void registerBlockWithItem(String path, class_2248 block)
    {
        class_2960 id = new class_2960(InfinityPatternProvider.MOD_ID, path);
        class_2378.method_10230(class_7923.field_41175, id, block);
        class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793()));
    }
}