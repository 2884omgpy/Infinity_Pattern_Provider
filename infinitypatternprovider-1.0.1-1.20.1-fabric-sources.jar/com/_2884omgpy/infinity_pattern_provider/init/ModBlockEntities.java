package com._2884omgpy.infinity_pattern_provider.init;

import com._2884omgpy.infinity_pattern_provider.InfinityPatternProvider;
import com._2884omgpy.infinity_pattern_provider.blockentity.InfinityPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.blockentity._1024SlotsPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.blockentity._1SlotsPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.blockentity._32SlotsPatternProviderBlockEntity;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities
{
    public static final class_2591<_1SlotsPatternProviderBlockEntity> _1SLOTS_PATTERN_PROVIDER = FabricBlockEntityTypeBuilder.create(_1SlotsPatternProviderBlockEntity::new, ModBlocks._1SLOTS_PATTERN_PROVIDER).build();
    public static final class_2591<_32SlotsPatternProviderBlockEntity> _32SLOTS_PATTERN_PROVIDER = FabricBlockEntityTypeBuilder.create(_32SlotsPatternProviderBlockEntity::new, ModBlocks._32SLOTS_PATTERN_PROVIDER).build();
    public static final class_2591<_1024SlotsPatternProviderBlockEntity> _1024SLOTS_PATTERN_PROVIDER = FabricBlockEntityTypeBuilder.create(_1024SlotsPatternProviderBlockEntity::new, ModBlocks._1024SLOTS_PATTERN_PROVIDER).build();
    public static final class_2591<InfinityPatternProviderBlockEntity> INFINITY_PATTERN_PROVIDER = FabricBlockEntityTypeBuilder.create(InfinityPatternProviderBlockEntity::new, ModBlocks.INFINITY_PATTERN_PROVIDER).build();

    public static void register()
    {
        register("_1slots_pattern_provider", _1SLOTS_PATTERN_PROVIDER);
        register("_32slots_pattern_provider", _32SLOTS_PATTERN_PROVIDER);
        register("_1024slots_pattern_provider", _1024SLOTS_PATTERN_PROVIDER);
        register("infinity_pattern_provider", INFINITY_PATTERN_PROVIDER);
    }

    private static void register(String path, class_2591<?> type)
    {
        class_2378.method_10230(class_7923.field_41181, new class_2960(InfinityPatternProvider.MOD_ID, path), type);
    }
}