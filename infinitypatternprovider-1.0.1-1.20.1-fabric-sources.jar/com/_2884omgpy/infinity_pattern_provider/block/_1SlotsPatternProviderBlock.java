package com._2884omgpy.infinity_pattern_provider.block;

import appeng.block.crafting.PushDirection;
import appeng.menu.locator.MenuLocators;
import appeng.util.InteractionUtil;
import appeng.util.Platform;
import com._2884omgpy.infinity_pattern_provider.blockentity._1SlotsPatternProviderBlockEntity;
import com._2884omgpy.infinity_pattern_provider.menu.BlockBaseGui;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3965;
import org.jetbrains.annotations.NotNull;

import static appeng.block.crafting.PatternProviderBlock.PUSH_DIRECTION;

public class _1SlotsPatternProviderBlock extends BlockBaseGui<_1SlotsPatternProviderBlockEntity>
{
    public _1SlotsPatternProviderBlock()
    {
        super(metalProps());
        this.method_9590(this.method_9564().method_11657(PUSH_DIRECTION, PushDirection.ALL));
    }

    //添加push方向
    @Override
    protected void method_9515(@NotNull class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);
        builder.method_11667(PUSH_DIRECTION);
    }

    //检测周围方块更新
    @Override
    public void method_9612(@NotNull class_2680 blockState, @NotNull class_1937 level, @NotNull class_2338 blockPosition, @NotNull class_2248 block, @NotNull class_2338 fromPosition, boolean isMoving)
    {
        var blockEntity = this.getBlockEntity(level, blockPosition);
        if (blockEntity != null)
        {
            blockEntity.getLogic().updateRedstoneState();
        }
    }

    //交互结果
    @Override
    public class_1269 check(_1SlotsPatternProviderBlockEntity blockEntity, class_1799 itemStack, class_1937 world, class_2338 blockPosition, class_3965 blockHitResult, class_1657 player)
    {
        if (itemStack != null && InteractionUtil.canWrenchRotate(itemStack))
        {
            this.setSide(world, blockPosition, blockHitResult.method_17780());
            return class_1269.method_29236(world.method_8608());
        }
        return null;
    }

    //打开GUI
    @Override
    public void openGui(class_2586 blockEntity, class_1657 player)
    {
        if (blockEntity instanceof _1SlotsPatternProviderBlockEntity patternProvider)
        {
            patternProvider.openMenu(player, MenuLocators.forBlockEntity(patternProvider));
        }
    }

    //设置方向
    public void setSide(class_1937 level, class_2338 blockPos, class_2350 facingDirection)
    {
        var currentState = level.method_8320(blockPos);
        var pushSide = currentState.method_11654(PUSH_DIRECTION).getDirection();

        PushDirection newPushDirection;
        if (pushSide == facingDirection.method_10153())   //背对>>>面对
        {
            newPushDirection = PushDirection.fromDirection(facingDirection);
        }
        else
            if (pushSide == facingDirection)             //面对>>>全部
            {
                newPushDirection = PushDirection.ALL;
            }
            else
                if (pushSide == null)           //无方向>>>背对
                {
                    newPushDirection = PushDirection.fromDirection(facingDirection.method_10153());
                }
                    else                        //旋转
                    {
                        newPushDirection = PushDirection.fromDirection(Platform.rotateAround(pushSide, facingDirection));
                    }

        //方块更新
        level.method_8501(blockPos, currentState.method_11657(PUSH_DIRECTION, newPushDirection));
    }
}